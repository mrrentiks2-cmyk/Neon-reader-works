package app.neonreader;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class MainActivity extends Activity {
    static final String HOST = "appassets.androidplatform.net";
    static final String START = "https://" + HOST + "/assets/www/index.html";
    static final int REQ_FILE = 1;
    static final int REQ_PERM = 2;
    static final int REQ_SAVE = 3;
    static final int BG = Color.parseColor("#0a0912");

    WebView web;
    FrameLayout root;
    Chrome chrome;
    View customView;
    WebChromeClient.CustomViewCallback customCb;
    ValueCallback<Uri[]> fileCb;
    Uri cameraUri;
    boolean pageReady = false;
    final List<String> pendingOpen = new ArrayList<>();
    final Map<String, Uri> shared = new ConcurrentHashMap<>();
    final Map<String, Sink> sinks = new ConcurrentHashMap<>();

    static class Sink { OutputStream out; Uri uri; File file; String name; String mime; }
    final java.util.ArrayDeque<Sink> saveQueue = new java.util.ArrayDeque<>();
    Sink saving;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Window w = getWindow();
        w.setStatusBarColor(BG);
        w.setNavigationBarColor(BG);
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        web = new WebView(this);
        web.setBackgroundColor(BG);
        root.addView(web, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        if ((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) WebView.setWebContentsDebuggingEnabled(true);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/shared/", this::openShared)
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                openExternal(u);
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                flushOpen();
            }
        });
        chrome = new Chrome();
        web.setWebChromeClient(chrome);
        web.addJavascriptInterface(new Bridge(), "NeonAndroid");
        web.loadUrl(START);
        handleIntent(getIntent());

        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_PERM);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) web.evaluateJavascript("window.App && App.stashAll && App.stashAll()", null);
    }

    @Override
    public void onBackPressed() {
        if (customView != null) { chrome.onHideCustomView(); return; }
        web.evaluateJavascript("(window.__neonBack && window.__neonBack()) ? 1 : 0", r -> {
            if (!"1".equals(r)) finish();
        });
    }

    @Override
    protected void onDestroy() {
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }

    /* ---------- files coming from other apps ("Open with", "Share") ---------- */
    @SuppressWarnings("deprecation")
    void handleIntent(Intent i) {
        if (i == null) return;
        String a = i.getAction();
        List<Uri> uris = new ArrayList<>();
        try {
            if (Intent.ACTION_VIEW.equals(a) && i.getData() != null) uris.add(i.getData());
            else if (Intent.ACTION_SEND.equals(a)) { Uri u = i.getParcelableExtra(Intent.EXTRA_STREAM); if (u != null) uris.add(u); }
            else if (Intent.ACTION_SEND_MULTIPLE.equals(a)) { ArrayList<Uri> l = i.getParcelableArrayListExtra(Intent.EXTRA_STREAM); if (l != null) uris.addAll(l); }
        } catch (Exception ignored) { }
        for (Uri u : uris) {
            String t = UUID.randomUUID().toString();
            shared.put(t, u);
            pendingOpen.add("[" + JSONObject.quote("https://" + HOST + "/shared/" + t) + "," + JSONObject.quote(nameOf(u)) + "]");
        }
        flushOpen();
    }

    void flushOpen() {
        if (!pageReady || pendingOpen.isEmpty() || web == null) return;
        String js = "window.__neonOpenMany && window.__neonOpenMany([" + String.join(",", pendingOpen) + "])";
        pendingOpen.clear();
        web.evaluateJavascript(js, null);
    }

    WebResourceResponse openShared(String path) {
        Uri u = shared.get(path);
        if (u == null) return null;
        try {
            InputStream in = getContentResolver().openInputStream(u);
            String mime = getContentResolver().getType(u);
            if (mime == null) mime = "application/octet-stream";
            WebResourceResponse r = new WebResourceResponse(mime, null, in);
            Map<String, String> h = new HashMap<>();
            h.put("Cache-Control", "no-store");
            r.setResponseHeaders(h);
            return r;
        } catch (Exception e) {
            return null;
        }
    }

    String nameOf(Uri u) {
        String n = null;
        try (Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) n = c.getString(0);
        } catch (Exception ignored) { }
        if (n == null) n = u.getLastPathSegment();
        if (n == null) n = "file";
        if (!n.contains(".")) {
            String ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(getContentResolver().getType(u));
            if (ext != null) n = n + "." + ext;
        }
        return n;
    }

    void openExternal(Uri u) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, u)); }
        catch (Exception e) { Toast.makeText(this, "Нет приложения для открытия ссылки", Toast.LENGTH_SHORT).show(); }
    }

    /* ---------- file picker & camera for <input type=file> ---------- */
    class Chrome extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
            if (fileCb != null) fileCb.onReceiveValue(null);
            fileCb = cb;
            cameraUri = null;
            String[] types = cleanTypes(p.getAcceptTypes());
            try {
                if (p.isCaptureEnabled() && types.length == 1 && types[0].startsWith("image/")) {
                    File dir = new File(getCacheDir(), "camera");
                    dir.mkdirs();
                    File img = new File(dir, "photo_" + System.currentTimeMillis() + ".jpg");
                    cameraUri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".files", img);
                    Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    cam.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
                    cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivityForResult(cam, REQ_FILE);
                    return true;
                }
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(types.length == 1 ? types[0] : "*/*");
                if (types.length > 1) i.putExtra(Intent.EXTRA_MIME_TYPES, types);
                if (p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                startActivityForResult(Intent.createChooser(i, "Выберите файл"), REQ_FILE);
                return true;
            } catch (Exception e) {
                fileCb = null;
                cameraUri = null;
                cb.onReceiveValue(null);
                Toast.makeText(MainActivity.this, "Не удалось открыть выбор файлов", Toast.LENGTH_SHORT).show();
                return true;
            }
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback cb) {
            if (customView != null) { cb.onCustomViewHidden(); return; }
            customView = view;
            customCb = cb;
            root.addView(view, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            web.setVisibility(View.GONE);
        }

        @Override
        public void onHideCustomView() {
            if (customView == null) return;
            root.removeView(customView);
            customView = null;
            web.setVisibility(View.VISIBLE);
            if (customCb != null) customCb.onCustomViewHidden();
            customCb = null;
        }
    }

    String[] cleanTypes(String[] in) {
        List<String> out = new ArrayList<>();
        if (in != null) for (String raw : in) {
            if (raw == null) continue;
            for (String t : raw.split(",")) {
                t = t.trim().toLowerCase();
                if (t.isEmpty()) continue;
                if (t.startsWith(".")) {
                    String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(t.substring(1));
                    if (m != null && !out.contains(m)) out.add(m);
                } else if (t.contains("/") && !out.contains(t)) out.add(t);
            }
        }
        if (out.isEmpty()) out.add("*/*");
        return out.toArray(new String[0]);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_SAVE) { finishSave(res == RESULT_OK && data != null ? data.getData() : null); return; }
        if (req != REQ_FILE || fileCb == null) return;
        Uri[] out = null;
        if (res == RESULT_OK) {
            if (cameraUri != null) out = new Uri[]{cameraUri};
            else if (data != null) {
                ClipData cd = data.getClipData();
                if (cd != null && cd.getItemCount() > 0) {
                    out = new Uri[cd.getItemCount()];
                    for (int k = 0; k < out.length; k++) out[k] = cd.getItemAt(k).getUri();
                } else if (data.getData() != null) out = new Uri[]{data.getData()};
            }
        }
        fileCb.onReceiveValue(out);
        fileCb = null;
        cameraUri = null;
    }

    /* ---------- saving files: system "Save as" dialog (user picks the folder) ---------- */
    void nextSave() {
        if (saving != null || saveQueue.isEmpty()) return;
        saving = saveQueue.poll();
        try {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType(saving.mime);
            i.putExtra(Intent.EXTRA_TITLE, saving.name);
            startActivityForResult(i, REQ_SAVE);
        } catch (Exception e) {
            Uri u = saveToDownloads(saving);
            toast(u != null ? "Сохранено в «Загрузки/Neon Reader»: " + saving.name : "Не удалось сохранить файл");
            saving.file.delete();
            saving = null;
            nextSave();
        }
    }

    void finishSave(Uri target) {
        Sink k = saving;
        saving = null;
        if (k == null) return;
        if (target == null) toast("Сохранение отменено");
        else {
            try (InputStream in = new java.io.FileInputStream(k.file); OutputStream out = getContentResolver().openOutputStream(target, "wt")) {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                toast("Сохранено: " + nameOf(target));
            } catch (Exception e) {
                toast("Не удалось сохранить: " + e.getMessage());
            }
        }
        k.file.delete();
        nextSave();
    }

    /* fallback when no file picker app is available */
    Uri saveToDownloads(Sink k) {
        try {
            OutputStream out;
            Uri uri = null;
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Downloads.DISPLAY_NAME, k.name);
                cv.put(MediaStore.Downloads.MIME_TYPE, k.mime);
                cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Neon Reader");
                uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (uri == null) return null;
                out = getContentResolver().openOutputStream(uri);
            } else {
                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Neon Reader");
                dir.mkdirs();
                File f = new File(dir, k.name);
                out = new FileOutputStream(f);
                MediaScannerConnection.scanFile(this, new String[]{f.getAbsolutePath()}, null, null);
                uri = Uri.fromFile(f);
            }
            try (InputStream in = new java.io.FileInputStream(k.file)) {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            out.close();
            return uri;
        } catch (Exception e) {
            return null;
        }
    }

    void toast(String t) { runOnUiThread(() -> Toast.makeText(MainActivity.this, t, Toast.LENGTH_LONG).show()); }

    class Bridge {
        @JavascriptInterface
        public String begin(String name, String mime) {
            try {
                String safe = name.replaceAll("[\\\\/:*?\"<>|\\u0000-\\u001f]", "_");
                if (safe.trim().isEmpty()) safe = "file";
                Sink k = new Sink();
                k.name = safe;
                k.mime = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
                File dir = new File(getCacheDir(), "out");
                dir.mkdirs();
                k.file = new File(dir, UUID.randomUUID().toString());
                k.out = new FileOutputStream(k.file);
                String id = UUID.randomUUID().toString();
                sinks.put(id, k);
                return id;
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public boolean append(String id, String b64) {
            Sink k = sinks.get(id);
            if (k == null) return false;
            try { k.out.write(Base64.decode(b64, Base64.DEFAULT)); return true; }
            catch (Exception e) { return false; }
        }

        @JavascriptInterface
        public String finish(String id) {
            final Sink k = sinks.remove(id);
            if (k == null) return "";
            try { k.out.close(); } catch (Exception e) { return ""; }
            runOnUiThread(() -> { saveQueue.add(k); nextSave(); });
            return "ok";
        }

        @JavascriptInterface
        public String platform() { return "android"; }
    }
}
